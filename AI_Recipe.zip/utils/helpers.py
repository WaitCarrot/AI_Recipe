# 辅助函数
def format_response(response):
    """格式化API响应"""
    return response
